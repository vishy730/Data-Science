#!/usr/bin/env python
# -*- coding: utf-8 -*-
import xml.etree.cElementTree as ET
import pprint
import re
import codecs
import json
from pymongo import MongoClient


lower = re.compile(r'^([a-z]|_)*$')
lower_colon = re.compile(r'^([a-z]|_)*:([a-z]|_)*$')
problemchars = re.compile(r'[=\+/&<>;\'"\?%#$@\,\. \t\r\n]')
sample = 'sample.json'

CREATED = [ "version", "changeset", "timestamp", "user", "uid"]

ADDRESS = ["housenumber", "street", "postcode", "city"]

OSMFILE = "hyderabad_india.osm"

expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road",
            "Trail", "Parkway", "Commons"]

mapping = { " St": " Street",
            "Ave": "Avenue",
            " rd": " Road",
            " rd ": " Road",
            "Rd": "Road",
            " Rd": " Road",
            "Rd,": " Road",
            "road":"Road",
            "ln": "Lane",
            "Ln": "Lane",
            "Apts": "Apartments",
            " st ": " Street",
            "RD": "Road",
            "Jn": "Junction"
          }

def update_name(name, mapping):
    for i in mapping:
        match = re.search(r'\b' +i+ r'\b', name)
        if match:
            #using dollar to search the end of the string and ^ for start of the string.
            name = re.sub(i,mapping[i],name)

    return name

def shape_element(element):
    node = {}
    if element.tag == "node" or element.tag == "way" :
        created = {}
        address = {}
        node_refs = []
        try:
            POS = []
            POS = [float(element.attrib['lat']),float(element.attrib['lon'])]
        except:
            pass
        node["pos"] = POS
        node["id"] = element.attrib["id"]
        node["type"] = element.tag
        node["visible"] = element.get("visible")
        for elem in element.iter("tag"):
            #print 'inside tag for loop'
            #print elem.attrib['k']
            #print elem.attrib['v']
            if elem.attrib['k'] == "amenity":
                node["amenity"] = re.sub(r'_'," ", elem.attrib['v'])
            elif elem.attrib['k'] == "name":
                if len(elem.attrib['v']) > 1:
                    node["name"] = update_name(elem.attrib['v'], mapping)
            else:
                pass
        for i in element.attrib.keys():
            if i in CREATED:
                created[i] = element.attrib[i]
                #print created
                node["created"] = created
        for addr in element:
            if addr.tag == "tag":
                if re.match(problemchars,addr.get('k')):
                    continue
                elif re.search(r'\w+:\w+:\w+', addr.get('k')):
                    pass
                elif addr.attrib['k'].startswith('addr'):
                    address[addr.get('k')[5:]] = addr.get('v')
                    node['address'] = address
                else:
                    #node[addr.get('k')] = addr.get('v')
                    pass
            else:
                if addr.tag == 'nd':
                    node_refs.append(addr.attrib['ref'])
                else:
                    pass
        if node_refs:
            node['node_refs'] = node_refs

        #print node
        return node
    else:
        return None


def process_map(file_in, pretty = True):
    # Json conversion.
    file_out = "{0}.json".format(file_in)
    data = []
    with codecs.open(file_out, "w") as fo:
        for _, element in ET.iterparse(file_in):
            el = shape_element(element)
            if el:
                data.append(el)
                if pretty:
                    fo.write(json.dumps(el, indent=2)+"\n")
                else:
                    fo.write(json.dumps(el) + "\n")
    return data

def test():

    data = process_map(OSMFILE, True)
    #pprint.pprint(data)
    #client = MongoClient('mongodb://localhost:27017:/')
    #db = client.osmdb
    #db.osmdb.insert(sample)




if __name__ == "__main__":
    test()